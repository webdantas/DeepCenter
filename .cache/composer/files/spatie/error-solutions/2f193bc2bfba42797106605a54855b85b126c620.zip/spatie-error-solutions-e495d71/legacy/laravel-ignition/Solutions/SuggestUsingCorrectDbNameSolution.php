<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\SuggestUsingCorrectDbNameSolution as BaseSuggestUsingCorrectDbNameSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestUsingCorrectDbNameSolution extends BaseSuggestUsingCorrectDbNameSolutionAlias  implements Solution
{

}
