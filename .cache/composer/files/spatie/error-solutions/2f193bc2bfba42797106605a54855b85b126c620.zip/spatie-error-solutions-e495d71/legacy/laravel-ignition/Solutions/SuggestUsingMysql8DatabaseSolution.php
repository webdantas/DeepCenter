<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\SuggestUsingMysql8DatabaseSolution as BaseSuggestUsingMysql8DatabaseSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestUsingMysql8DatabaseSolution extends BaseSuggestUsingMysql8DatabaseSolutionAlias implements Solution
{

}
