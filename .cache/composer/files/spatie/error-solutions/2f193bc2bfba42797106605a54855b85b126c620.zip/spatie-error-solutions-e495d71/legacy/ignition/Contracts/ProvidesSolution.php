<?php

namespace Spatie\Ignition\Contracts;

interface ProvidesSolution extends \Spatie\ErrorSolutions\Contracts\ProvidesSolution
{
}
